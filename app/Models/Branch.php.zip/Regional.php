<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Regional extends Model
{
    // protected $table = 'regions';

    protected $fillable = ['title'];
}
