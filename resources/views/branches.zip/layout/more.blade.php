<!-- start: Javascript -->
<script src="{{ asset('miminium-master/asset/js/jquery.min.js')}}"></script>
<script src="{{ asset('miminium-master/asset/js/jquery.ui.min.js')}}"></script>
<script src="{{ asset('miminium-master/asset/js/bootstrap.min.js')}}"></script>



<!-- plugins -->
<script src="{{ asset('miminium-master/asset/js/plugins/moment.min.js')}}"></script>
<script src="{{ asset('miminium-master/asset/js/plugins/jquery.datatables.min.js')}}"></script>
<script src="{{ asset('miminium-master/asset/js/plugins/datatables.bootstrap.min.js')}}"></script>
<script src="{{ asset('miminium-master/asset/js/plugins/jquery.nicescroll.js')}}"></script>
<script src="{{ asset('miminium-master/asset/js/plugins/bootstrap-material-datetimepicker.js')}}"></script>

<script src="{{ asset('miminium-master/asset/js/main.js')}}"></script>