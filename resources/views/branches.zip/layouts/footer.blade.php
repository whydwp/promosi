<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <script>document.write(new Date().getFullYear())</script> © Pesta Pora Abadi - Mie Gacoan.co.id
            </div>
        </div>
    </div>
</footer>